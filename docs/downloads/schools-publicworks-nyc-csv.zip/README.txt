Schools Finder (schools.publicworks.nyc), public data archive
======================================================

Generated 2026-08-26 from the sources listed in sources.csv.

Files
-----
schools.csv              One row per DBN. Identity, location, and current attributes.
observations.csv         One row per DBN, school year, and metric. Every published value.
metrics.csv              One row per metric. Definitions, units, and which schools they apply to.
programs.csv             One row per DBN and program, where a directory publishes one.
program_priorities.csv   One row per DBN, program, and priority rank.
sources.csv              Every source, with its period, coverage, and limitations.
data-dictionary.csv      Every field in every file above.

Reading the values
------------------
Join on dbn. Never join on a school name.

An empty value is not a zero. The status column in observations.csv says which
kind of absence it is:

  reported     the source published a value
  suppressed   the source withheld the value to protect a small group
  missing      the source published no value

A metric that does not apply to a school type is absent from these files
entirely rather than present and empty. metrics.csv states which report types
each metric applies to.

Percentages are proportions between 0 and 1 unless metrics.csv says otherwise.

Limits
------
This archive contains no ranking, no score, and no recommendation. Values from
different school years or different metrics are not always comparable; see the
comparability notes in metrics.csv and the methodology page on the site.

Licence and credit
------------------
The underlying data is published by New York City Public Schools and NYC
OpenData. Credit them for the data and Schools Finder (schools.publicworks.nyc) for
the compilation.
